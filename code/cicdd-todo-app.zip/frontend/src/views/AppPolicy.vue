<template>
  <div class="px-4 sm:px-6 lg:px-8">
    <div class="relative mx-auto max-w-[37.5rem] pt-20 text-center pb-24">
      <h1 class="text-4xl tracking-tight text-slate-900 sm:text-5xl dark:text-white">
        Politique de confidentialité
      </h1>
      <p class="mt-4 text-base/7 text-slate-600 dark:text-gray-400">
        Dernière mise à jour le 27 mars 2025
      </p>
    </div>
  </div>
  <div class="relative px-4 sm:px-6 lg:px-8">
    <div
      class="mx-auto max-w-[40rem] prose prose-sm prose-slate prose-a:font-semibold prose-a:text-sky-500 prose-a:no-underline prose-a:hover:text-sky-600 prose-code:text-[13px]/[1.692] prose-pre:rounded-lg prose-pre:px-4 prose-pre:py-[0.875rem] dark:text-white"
    >
      <p>
        Cette politique de confidentialité (« Politique ») décrit comment Matinfo Labs. Labs Inc. («
        Matinfo Labs. », « nous », « notre » ou « nos ») collecte, protège et utilise les
        informations personnelles identifiables (« Informations personnelles ») que vous («
        Utilisateur », « vous » ou « votre ») pouvez fournir via le site TodoApp (todoapp.com). La
        Politique décrit également les choix qui s'offrent à vous concernant notre utilisation de
        vos Informations personnelles et comment vous pouvez accéder à ces informations et les
        mettre à jour. Cette Politique ne s'applique pas aux pratiques des sociétés que nous ne
        possédons pas ou ne contrôlons pas, ni aux personnes que nous n'employons pas ou ne gérons
        pas.
      </p>
      <h2>Collecte de renseignements personnels</h2>
      <p>
        Nous recevons et stockons toutes les informations que vous nous fournissez en toute
        connaissance de cause lorsque vous effectuez un achat via le site Web. Actuellement, cela se
        limite à votre adresse e-mail, qui est nécessaire pour que vous puissiez vous connecter au
        site Web et accéder à vos todo.
      </p>
      <h2>Collecte d'informations non personnelles</h2>
      <p>
        Lorsque vous visitez le site Web, nos serveurs enregistrent automatiquement les informations
        envoyées par votre navigateur. Ces données peuvent inclure des informations telles que
        l'adresse IP de votre appareil, le type et la version du navigateur, le type et la version
        du système d'exploitation, les préférences linguistiques ou la page Web que vous visitiez
        avant de venir sur notre site Web, les pages de notre site Web que vous visitez, le temps
        passé sur ces pages, les informations que vous recherchez sur notre site Web, les heures et
        dates d'accès et d'autres statistiques.
      </p>
      <h2>Gestion des informations personnelles</h2>
      <p>
        Vous pouvez mettre à jour vos informations personnelles dans les « Paramètres de votre
        compte » sur le site Web. Actuellement, cela se limite à votre adresse e-mail, comme décrit
        ci-dessus. Vous pouvez également demander que nous supprimions votre adresse e-mail, mais
        cela supprimera aussi tous les todo que vous avez ajouté.
      </p>
      <p>
        Lorsque vous mettez à jour des informations, nous pouvons conserver une copie des
        informations non révisées dans nos archives. Certaines informations peuvent rester dans nos
        archives privées après la suppression de ces informations de votre compte pendant une
        période de conservation. Une fois la période de conservation expirée, les informations
        personnelles seront supprimées. Par conséquent, le droit d'accès, le droit d'effacement, vos
        droits d'accès, d'ajout et de mise à jour de vos informations ne peuvent pas être appliqués
        après l'expiration de la période de conservation.
      </p>
      <p>
        Nous conserverons et utiliserons vos informations si nécessaire pour nous conformer à nos
        obligations légales, résoudre les litiges et faire respecter nos accords. Nous pouvons
        utiliser toutes les données agrégées dérivées de vos informations personnelles ou les
        intégrant après leur mise à jour ou leur suppression, mais pas d'une manière qui permettrait
        de vous identifier personnellement.
      </p>
      <h2>Utilisation et traitement des informations collectées</h2>
      <p>
        Toutes les informations que nous recueillons auprès de vous peuvent être utilisées pour
        personnaliser votre expérience, améliorer notre site Web, améliorer le service client,
        traiter les transactions, envoyer des e-mails de notification tels que des rappels de mot de
        passe, des mises à jour, etc. et exploiter notre site Web. Les informations non personnelles
        collectées sont utilisées uniquement pour identifier les cas potentiels d'abus et établir
        des informations statistiques concernant l'utilisation du site Web. Ces informations
        statistiques ne sont pas autrement agrégées de manière à identifier un utilisateur
        particulier du système.
      </p>
      <p>
        Nous pouvons traiter des informations personnelles vous concernant si l'une des conditions
        suivantes s'applique : (i) Vous avez donné votre consentement pour une ou plusieurs
        finalités spécifiques. Veuillez noter que, dans le cadre de certaines législations, nous
        pouvons être autorisés à traiter des informations jusqu'à ce que vous vous opposiez à un tel
        traitement (en vous désinscrivant), sans avoir à nous appuyer sur le consentement ou sur
        l'une des autres bases juridiques ci-dessous. Cela ne s'applique toutefois pas lorsque le
        traitement des informations personnelles est soumis à la législation européenne sur la
        protection des données ; (ii) La fourniture d'informations est nécessaire à l'exécution d'un
        accord avec vous et/ou à toute obligation précontractuelle de celui-ci ; (ii) Le traitement
        est nécessaire au respect d'une obligation légale à laquelle vous êtes soumis ; (iv) Le
        traitement est lié à une tâche effectuée dans l'intérêt public ou dans l'exercice de
        l'autorité publique qui nous est conférée ; (v) Le traitement est nécessaire aux fins des
        intérêts légitimes poursuivis par nous ou par un tiers. Dans tous les cas, nous serons
        heureux de clarifier la base juridique spécifique qui s'applique au traitement, et en
        particulier si la fourniture de données personnelles est une exigence légale ou
        contractuelle, ou une exigence nécessaire à la conclusion d'un contrat.
      </p>
      <h2>Transfert et stockage d'informations</h2>
      <p>
        En fonction de votre localisation, les transferts de données peuvent impliquer le transfert
        et le stockage de vos informations dans un pays autre que le vôtre. Vous avez le droit de
        vous renseigner sur la base juridique des transferts d'informations vers un pays situé hors
        de l'Union européenne ou vers toute organisation internationale régie par le droit
        international public ou créée par deux ou plusieurs pays, comme l'ONU, ainsi que sur les
        mesures de sécurité que nous prenons pour protéger vos informations. Si un tel transfert a
        lieu, vous pouvez en savoir plus en consultant les sections correspondantes de ce document
        ou en vous renseignant auprès de nous en utilisant les informations fournies dans la section
        Contact.
      </p>
      <h2>Les droits des utilisateurs</h2>
      <p>
        Vous pouvez exercer certains droits concernant vos informations traitées par nous. En
        particulier, vous avez le droit de faire ce qui suit : (i) vous avez le droit de retirer
        votre consentement lorsque vous avez précédemment donné votre consentement au traitement de
        vos informations ; (ii) vous avez le droit de vous opposer au traitement de vos informations
        si le traitement est effectué sur une base juridique autre que le consentement ; (iii) vous
        avez le droit de savoir si des informations sont traitées par nous, d'obtenir des
        informations sur certains aspects du traitement et d'obtenir une copie des informations en
        cours de traitement ; (iv) vous avez le droit de vérifier l'exactitude de vos informations
        et de demander qu'elles soient mises à jour ou corrigées ; (v) vous avez le droit, dans
        certaines circonstances, de restreindre le traitement de vos informations, auquel cas nous
        ne traiterons pas vos informations à d'autres fins que leur stockage ; (vi) vous avez le
        droit, dans certaines circonstances, d'obtenir de nous l'effacement de vos informations
        personnelles ; (vii) vous avez le droit de recevoir vos informations dans un format
        structuré, couramment utilisé et lisible par machine et, si cela est techniquement possible,
        de les faire transmettre à un autre responsable du traitement sans aucune entrave. Cette
        disposition est applicable à condition que vos informations soient traitées par des moyens
        automatisés et que le traitement soit fondé sur votre consentement, sur un contrat auquel
        vous êtes partie ou sur des obligations précontractuelles de celui-ci.
      </p>
      <h2>Le droit de s'opposer au traitement</h2>
      <p>
        Lorsque des informations personnelles sont traitées dans l'intérêt public, dans l'exercice
        d'une autorité officielle qui nous est conférée ou aux fins des intérêts légitimes que nous
        poursuivons, vous pouvez vous opposer à un tel traitement en fournissant un motif lié à
        votre situation particulière pour justifier l'objection. Vous devez toutefois savoir que si
        vos informations personnelles sont traitées à des fins de marketing direct, vous pouvez vous
        opposer à ce traitement à tout moment sans fournir de justification. Pour savoir si nous
        traitons des informations personnelles à des fins de marketing direct, vous pouvez vous
        référer aux sections correspondantes du présent document.
      </p>
      <h2>Comment exercer ces droits</h2>
      <p>
        Toute demande d'exercice des droits de l'Utilisateur peut être adressée au Propriétaire par
        courrier électronique à l'<a href="mailto:support@todoapp.com"
          >adresse support@todoapp.com</a
        >. Ces demandes peuvent être exercées gratuitement et seront étudiées par le Propriétaire le
        plus tôt possible et toujours dans un délai d'un mois.
      </p>
      <h2>Vie privée des enfants</h2>
      <p>
        Nous ne collectons pas sciemment d'informations personnelles auprès d'enfants de moins de 13
        ans. Si vous avez moins de 13 ans, veuillez ne pas soumettre d'informations personnelles via
        notre site Web. Nous encourageons les parents et les tuteurs légaux à surveiller
        l'utilisation d'Internet par leurs enfants et à contribuer à l'application de cette
        politique en demandant à leurs enfants de ne jamais fournir d'informations personnelles via
        notre site Web sans leur autorisation. Si vous avez des raisons de croire qu'un enfant de
        moins de 13 ans nous a fourni des informations personnelles via notre site Web, veuillez
        nous contacter.
      </p>
      <h2>Cookies</h2>
      <p>
        Le site Web utilise des « cookies » pour personnaliser votre expérience en ligne. Un cookie
        est un fichier texte placé sur votre disque dur par un serveur de pages Web. Les cookies ne
        peuvent pas être utilisés pour exécuter des programmes ou transmettre des virus à votre
        ordinateur. Les cookies vous sont attribués de manière unique et ne peuvent être lus que par
        un serveur Web du domaine qui vous a émis le cookie. Nous pouvons utiliser des cookies pour
        collecter, stocker et suivre des informations à des fins statistiques pour faire fonctionner
        notre site Web. Vous avez la possibilité d'accepter ou de refuser les cookies. La plupart
        des navigateurs Web acceptent automatiquement les cookies, mais vous pouvez généralement
        modifier les paramètres de votre navigateur pour refuser les cookies si vous le préférez.
      </p>
      <p>
        Outre l'utilisation de cookies et de technologies connexes comme décrit ci-dessus, nous
        pouvons également autoriser certaines sociétés tierces à nous aider à personnaliser les
        publicités qui, selon nous, pourraient intéresser les utilisateurs et à collecter et
        utiliser d'autres données sur les activités des utilisateurs sur le site Web. Ces sociétés
        peuvent diffuser des publicités susceptibles de placer des cookies et de suivre le
        comportement des utilisateurs.
      </p>
      <h2>Liens vers d'autres sites Web</h2>
      <p>
        Notre site Web contient des liens vers d'autres sites Web qui ne nous appartiennent pas ou
        ne sont pas contrôlés par nous. Veuillez noter que nous ne sommes pas responsables des
        pratiques de confidentialité de ces autres sites Web ou de ces tiers. Nous vous encourageons
        à être vigilant lorsque vous quittez notre site Web et à lire les déclarations de
        confidentialité de chaque site Web susceptible de collecter des informations personnelles.
      </p>
      <h2>Sécurité de l'information</h2>
      <p>
        Nous sécurisons les informations que vous nous fournissez sur des serveurs informatiques
        dans un environnement contrôlé et sécurisé, protégé contre tout accès, utilisation ou
        divulgation non autorisés. Nous maintenons des mesures de protection administratives,
        techniques et physiques raisonnables dans le but de protéger contre tout accès, utilisation,
        modification et divulgation non autorisés des informations personnelles sous notre contrôle
        et notre garde. Cependant, aucune transmission de données sur Internet ou sur un réseau sans
        fil ne peut être garantie. Par conséquent, bien que nous nous efforcions de protéger vos
        informations personnelles, vous reconnaissez que (i) il existe des limitations de sécurité
        et de confidentialité sur Internet qui sont hors de notre contrôle ; (ii) la sécurité,
        l'intégrité et la confidentialité de toutes les informations et données échangées entre vous
        et notre site Web ne peuvent être garanties ; et (iii) ces informations et données peuvent
        être consultées ou falsifiées en transit par un tiers, malgré tous les efforts.
      </p>
      <h2>Violation de données</h2>
      <p>
        Si nous prenons connaissance que la sécurité du site Web a été compromise ou que les
        informations personnelles des utilisateurs ont été divulguées à des tiers non liés à la
        suite d'une activité externe, y compris, mais sans s'y limiter, des attaques de sécurité ou
        une fraude, nous nous réservons le droit de prendre des mesures raisonnablement appropriées,
        y compris, mais sans s'y limiter, des enquêtes et des rapports, ainsi que la notification et
        la coopération avec les autorités chargées de l'application de la loi. En cas de violation
        de données, nous ferons des efforts raisonnables pour informer les personnes concernées si
        nous pensons qu'il existe un risque raisonnable de préjudice pour l'utilisateur à la suite
        de la violation ou si une notification est autrement requise par la loi. Dans ce cas, nous
        vous enverrons un e-mail.
      </p>
      <h2>Divulgation légale</h2>
      <p>
        Nous divulguerons toute information que nous collectons, utilisons ou recevons si la loi
        l'exige ou le permet, par exemple pour nous conformer à une assignation à comparaître ou à
        une procédure judiciaire similaire, et lorsque nous pensons de bonne foi que la divulgation
        est nécessaire pour protéger nos droits, protéger votre sécurité ou celle d'autrui, enquêter
        sur une fraude ou répondre à une demande gouvernementale. Dans le cas où nous subirions une
        transition commerciale, telle qu'une fusion ou une acquisition par une autre société, ou la
        vente de tout ou partie de ses actifs, votre compte d'utilisateur et vos données
        personnelles feront probablement partie des actifs transférés.
      </p>
      <h2>Modifications et amendements</h2>
      <p>
        Nous nous réservons le droit de modifier cette politique de confidentialité relative au site
        Web à tout moment, avec effet à compter de la publication d'une version mise à jour de cette
        politique sur le site Web. Lorsque nous le ferons, nous réviserons la date de mise à jour au
        bas de cette page. L'utilisation continue du site Web après de telles modifications
        constituera votre consentement à ces modifications.
      </p>
      <h2>Acceptation de cette politique</h2>
      <p>
        Vous reconnaissez avoir lu cette politique et accepter tous ses termes et conditions. En
        utilisant le site Web, vous acceptez d'être lié par cette politique. Si vous n'acceptez pas
        de respecter les termes de cette politique, vous n'êtes pas autorisé à utiliser ou à accéder
        au site Web.
      </p>
      <h2>Nous contacter</h2>
      <p>
        Si vous avez des questions sur cette politique, veuillez nous contacter par e-mail à
        <a href="mailto:contact@matinfolabs.com">contact@matinfolabs.com</a>.
      </p>
    </div>
  </div>
</template>

<style scoped>
h2 {
  margin-top: 1.6em;
  margin-bottom: 0.4em;
  font-size: 1.42857em;
  line-height: 1.4;
}
a {
  text-decoration: underline;
}
</style>
